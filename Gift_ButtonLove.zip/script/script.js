const messages = [
  "Bạn là người tuyệt vời nhất!",
  "Tôi yêu bạn nhiều lắm 💖",
  "Bạn làm cho thế giới tươi đẹp hơn!",
  "Một ngày vui vẻ nhé! 😊",
  "Bạn đáng yêu như Nyan Cat 🐱🌈"
];
function showLoveMessage() {
  const message = messages[Math.floor(Math.random() * messages.length)];
  document.getElementById("message").textContent = message;
  const pop = document.getElementById("popSound");
  const meow = document.getElementById("meowSound");
  pop.play();
  setTimeout(() => meow.play(), 500);
}